import UIKit


func decreaseCharacter(_ char: Character, val: UInt32) -> Character {
    guard let scalarValue = char.unicodeScalars.first?.value else {
        return "0"
    }
    
    if let a = UnicodeScalar(scalarValue - val) {
        return Character(a)
    } else {
        return "0"
    }
}




// start middle number.. like..... 100000


print("100000" < "100001")
print("100000#1" < "100001")


"a".starts(with: "")
